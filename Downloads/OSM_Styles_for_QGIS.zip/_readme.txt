Apply to OSM data downloaded and processed into Spatialite according to
instructions in Spatialite section of Open Source GIS workbook by Clare
Gordon.

Apply in properties > Style or Labels tab > Style button at bottom of window >
Load Style > choose style to apply and > Open
